# Simple List Grid

A dead simple list to grid (and vicea-versa, I'm sure) jquery plugin.

![Simple List Grid Example](https://github.com/clintconklin/simple-list-grid/blob/master/images/demo.gif)

